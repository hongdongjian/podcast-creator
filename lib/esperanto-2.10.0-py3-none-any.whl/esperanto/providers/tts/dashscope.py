"""Dashscope (Aliyun Bailian) Text-to-Speech provider implementation.

Supports Qwen-TTS models for speech synthesis.
Documentation: https://help.aliyun.com/zh/model-studio/qwen-tts
"""
import base64
import os
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Union

import httpx

from .base import AudioResponse, Model, TextToSpeechModel, Voice


class DashscopeTextToSpeechModel(TextToSpeechModel):
    """Dashscope (Aliyun Bailian) Text-to-Speech provider implementation.
    
    Supports Qwen-TTS models including:
    - qwen3-tts-flash: Latest model with 49 voices, supports multiple languages
    - qwen-tts: Legacy model with 7 voices, supports Chinese and English
    
    Features:
    - Multiple voice options (49 voices for qwen3-tts-flash)
    - Support for Chinese, English, and 8 other languages
    - Streaming audio output support
    - Non-streaming with audio URL response
    
    Example:
        >>> from esperanto.factory import AIFactory
        >>> tts = AIFactory.create_text_to_speech(provider="dashscope")
        >>> response = tts.generate_speech("你好世界", voice="Cherry")
        >>> with open("output.wav", "wb") as f:
        ...     f.write(response.audio_data)
    """
    
    DEFAULT_MODEL = "qwen3-tts-flash"
    DEFAULT_VOICE = "Cherry"
    PROVIDER = "dashscope"
    
    # Supported language types for Qwen3-TTS
    SUPPORTED_LANGUAGES = [
        "Auto",      # Default, auto-detect
        "Chinese",   # 中文(普通话及方言)
        "English",   # 英文
        "German",    # 德语
        "Italian",   # 意大利语
        "Portuguese",# 葡萄牙语
        "Spanish",   # 西班牙语
        "Japanese",  # 日语
        "Korean",    # 韩语
        "French",    # 法语
        "Russian",   # 俄语
    ]
    
    # Available voices for qwen3-tts-flash model
    QWEN3_TTS_VOICES = {
        # Female voices
        "Cherry": {"gender": "FEMALE", "description": "女声-活泼甜美"},
        "Serena": {"gender": "FEMALE", "description": "女声-温柔知性"},
        "Ethan": {"gender": "MALE", "description": "男声-阳光开朗"},
        "Chelsie": {"gender": "FEMALE", "description": "女声-清新自然"},
        "Camila": {"gender": "FEMALE", "description": "女声-甜美可爱"},
        "Vivian": {"gender": "FEMALE", "description": "女声-温婉大气"},
        "Bella": {"gender": "FEMALE", "description": "女声-温柔治愈"},
        "Willow": {"gender": "FEMALE", "description": "女声-温柔舒缓"},
        "Claire": {"gender": "FEMALE", "description": "女声-甜美活力"},
        "Dahlia": {"gender": "FEMALE", "description": "女声-大气端庄"},
        "Amber": {"gender": "FEMALE", "description": "女声-温柔细腻"},
        "Lily": {"gender": "FEMALE", "description": "女声-邻家女孩"},
        "Sophia": {"gender": "FEMALE", "description": "女声-知性优雅"},
        "Olivia": {"gender": "FEMALE", "description": "女声-甜美可人"},
        "Emma": {"gender": "FEMALE", "description": "女声-活泼开朗"},
        # Male voices
        "Benjamin": {"gender": "MALE", "description": "男声-沉稳大气"},
        "Charles": {"gender": "MALE", "description": "男声-磁性浑厚"},
        "William": {"gender": "MALE", "description": "男声-温和亲切"},
        "Daniel": {"gender": "MALE", "description": "男声-阳光活力"},
        "Henry": {"gender": "MALE", "description": "男声-儒雅稳重"},
        "Alexander": {"gender": "MALE", "description": "男声-成熟稳健"},
        "George": {"gender": "MALE", "description": "男声-低沉浑厚"},
        "Matthew": {"gender": "MALE", "description": "男声-清新自然"},
        "Edward": {"gender": "MALE", "description": "男声-亲切随和"},
        "Sebastian": {"gender": "MALE", "description": "男声-冷静理性"},
        "Ryan": {"gender": "MALE", "description": "男声-阳光帅气"},
        "Lucas": {"gender": "MALE", "description": "男声-活泼开朗"},
        "Oliver": {"gender": "MALE", "description": "男声-温暖治愈"},
        "Thomas": {"gender": "MALE", "description": "男声-稳重大气"},
        "James": {"gender": "MALE", "description": "男声-儒雅知性"},
        # Additional voices
        "Loong": {"gender": "MALE", "description": "男声-龙族领袖"},
        "Luca": {"gender": "MALE", "description": "男声-意大利口音"},
        "Luna": {"gender": "FEMALE", "description": "女声-优美动听"},
        "Stella": {"gender": "FEMALE", "description": "女声-明亮清脆"},
        "Sarah": {"gender": "FEMALE", "description": "女声-亲切随和"},
        "Anna": {"gender": "FEMALE", "description": "女声-甜美清纯"},
    }
    
    # Voices for legacy qwen-tts model
    QWEN_TTS_VOICES = {
        "Cherry": {"gender": "FEMALE", "description": "女声-活泼甜美"},
        "Serena": {"gender": "FEMALE", "description": "女声-温柔知性"},
        "Ethan": {"gender": "MALE", "description": "男声-阳光开朗"},
        "Chelsie": {"gender": "FEMALE", "description": "女声-清新自然"},
        "Loong": {"gender": "MALE", "description": "男声-龙族领袖"},
    }
    
    def __init__(
        self,
        model_name: Optional[str] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        language_type: str = "Auto",
        **kwargs
    ):
        """Initialize Dashscope TTS provider.
        
        Args:
            model_name: Name of the model to use (default: qwen3-tts-flash)
            api_key: Dashscope API key. If not provided, will try to get from 
                     DASHSCOPE_API_KEY environment variable
            base_url: Optional base URL for the API (default: https://dashscope.aliyuncs.com/api/v1)
            language_type: Language type for synthesis. Options: Auto, Chinese, English, 
                          German, Italian, Portuguese, Spanish, Japanese, Korean, French, Russian
            **kwargs: Additional configuration options
        """
        api_key = api_key or os.getenv("DASHSCOPE_API_KEY")
        if not api_key:
            raise ValueError(
                "Dashscope API key not provided. Set DASHSCOPE_API_KEY environment "
                "variable or pass api_key parameter."
            )

        super().__init__(
            model_name=model_name or self.DEFAULT_MODEL,
            api_key=api_key,
            base_url=base_url or "https://dashscope.aliyuncs.com/api/v1",
            config=kwargs
        )
        
        self.language_type = language_type
        
        # Initialize HTTP clients with configurable timeout
        self._create_http_clients()

    def _get_headers(self) -> Dict[str, str]:
        """Get headers for Dashscope API requests."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _handle_error(self, response: httpx.Response) -> None:
        """Handle HTTP error responses."""
        if response.status_code >= 400:
            try:
                error_data = response.json()
                error_message = error_data.get("message", f"HTTP {response.status_code}")
                error_code = error_data.get("code", "")
                if error_code:
                    error_message = f"{error_code}: {error_message}"
            except Exception:
                error_message = f"HTTP {response.status_code}: {response.text}"
            raise RuntimeError(f"Dashscope API error: {error_message}")

    def _get_voices_for_model(self) -> Dict[str, Dict[str, str]]:
        """Get available voices based on the current model."""
        if self.model_name and self.model_name.startswith("qwen3-tts"):
            return self.QWEN3_TTS_VOICES
        return self.QWEN_TTS_VOICES

    @property
    def available_voices(self) -> Dict[str, Voice]:
        """Get available voices for this TTS provider.

        Returns:
            Dict[str, Voice]: Dictionary of available voices with their information
        """
        voices = {}
        voice_data = self._get_voices_for_model()
        
        for voice_name, voice_info in voice_data.items():
            voices[voice_name] = Voice(
                name=voice_name,
                id=voice_name,
                gender=voice_info["gender"],
                language_code="zh-CN",  # Primary language is Chinese
                description=voice_info["description"],
            )
        return voices

    @property
    def provider(self) -> str:
        """Get the provider name."""
        return self.PROVIDER

    def _get_default_model(self) -> str:
        """Get the default model name."""
        return self.DEFAULT_MODEL

    def _get_models(self) -> List[Model]:
        """List all available models for this provider."""
        return [
            Model(
                id="qwen3-tts-flash",
                owned_by="alibaba",
                context_window=600,  # 600 characters max input
            ),
            Model(
                id="qwen3-tts-flash-2025-11-27",
                owned_by="alibaba",
                context_window=600,
            ),
            Model(
                id="qwen3-tts-flash-2025-09-18",
                owned_by="alibaba",
                context_window=600,
            ),
            Model(
                id="qwen-tts",
                owned_by="alibaba",
                context_window=512,  # 512 tokens max input
            ),
        ]

    def generate_speech(
        self,
        text: str,
        voice: str = "Cherry",
        output_file: Optional[Union[str, Path]] = None,
        language_type: Optional[str] = None,
        stream: bool = False,
        **kwargs
    ) -> AudioResponse:
        """Generate speech from text using Dashscope Qwen-TTS API.

        Args:
            text: Text to convert to speech (max 600 characters for qwen3-tts, 
                  512 tokens for qwen-tts)
            voice: Voice to use (default: "Cherry")
            output_file: Optional path to save the audio file
            language_type: Language type override. If not provided, uses instance default.
            stream: Whether to use streaming mode (default: False)
            **kwargs: Additional parameters to pass to the API

        Returns:
            AudioResponse containing the audio data and metadata

        Raises:
            RuntimeError: If speech generation fails
            ValueError: If input parameters are invalid
        """
        self.validate_parameters(text, voice, self.model_name)
        
        try:
            # Prepare request payload using MultiModalConversation API format
            payload = {
                "model": self.model_name,
                "text": text,
                "voice": voice,
                "stream": stream,
                "language_type": language_type or self.language_type,
                **kwargs
            }

            if stream:
                return self._generate_speech_streaming(payload, voice, output_file)
            else:
                return self._generate_speech_non_streaming(payload, voice, output_file)

        except Exception as e:
            if isinstance(e, (RuntimeError, ValueError)):
                raise
            raise RuntimeError(f"Failed to generate speech: {str(e)}") from e

    def _generate_speech_non_streaming(
        self,
        payload: Dict[str, Any],
        voice: str,
        output_file: Optional[Union[str, Path]] = None
    ) -> AudioResponse:
        """Generate speech in non-streaming mode (returns audio URL).
        
        Args:
            payload: Request payload
            voice: Voice name used
            output_file: Optional path to save the audio file
            
        Returns:
            AudioResponse with audio data
        """
        # Build request body with model at top level
        model = payload.pop("model")
        stream = payload.pop("stream", False)
        
        request_body = {
            "model": model,
            "input": payload,
        }
        
        # Call the multimodal conversation endpoint for TTS
        response = self.client.post(
            f"{self.base_url}/services/aigc/multimodal-generation/generation",
            headers=self._get_headers(),
            json=request_body,
        )
        self._handle_error(response)
        
        response_data = response.json()
        
        # Extract audio URL from response
        output = response_data.get("output", {})
        audio_info = output.get("audio", {})
        audio_url = audio_info.get("url")
        
        if not audio_url:
            raise RuntimeError("No audio URL in response")
        
        # Download audio from URL
        audio_response = self.client.get(audio_url)
        if audio_response.status_code != 200:
            raise RuntimeError(f"Failed to download audio: HTTP {audio_response.status_code}")
        
        audio_data = audio_response.content
        
        # Save to file if specified
        if output_file:
            output_file = Path(output_file)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_bytes(audio_data)

        # Extract usage info
        usage = response_data.get("usage", {})
        
        return AudioResponse(
            audio_data=audio_data,
            content_type="audio/wav",
            model=self.model_name,
            voice=voice,
            provider=self.PROVIDER,
            metadata={
                "text": payload.get("text"),
                "language_type": payload.get("language_type"),
                "audio_url": audio_url,
                "request_id": response_data.get("request_id"),
                "input_characters": usage.get("input_characters"),
                "output_tokens": usage.get("output_tokens"),
            }
        )

    def _generate_speech_streaming(
        self,
        payload: Dict[str, Any],
        voice: str,
        output_file: Optional[Union[str, Path]] = None
    ) -> AudioResponse:
        """Generate speech in streaming mode (returns base64 audio chunks).
        
        Args:
            payload: Request payload
            voice: Voice name used
            output_file: Optional path to save the audio file
            
        Returns:
            AudioResponse with concatenated audio data
        """
        # Build request body with model at top level
        model = payload.pop("model")
        stream = payload.pop("stream", True)
        
        request_body = {
            "model": model,
            "input": payload,
            "parameters": {
                "incremental_output": True
            }
        }
        
        # For streaming, we need to handle Server-Sent Events
        headers = self._get_headers()
        headers["Accept"] = "text/event-stream"
        headers["X-DashScope-SSE"] = "enable"
        
        response = self.client.post(
            f"{self.base_url}/services/aigc/multimodal-generation/generation",
            headers=headers,
            json=request_body,
        )
        self._handle_error(response)
        
        # Collect all audio chunks
        audio_chunks = []
        audio_url = None
        request_id = None
        
        for line in response.iter_lines():
            if not line:
                continue
            
            line_str = line.decode("utf-8") if isinstance(line, bytes) else line
            if line_str.startswith("data:"):
                try:
                    import json
                    data = json.loads(line_str[5:].strip())
                    output = data.get("output", {})
                    audio_info = output.get("audio", {})
                    
                    # Get base64 audio chunk
                    if audio_info.get("data"):
                        chunk_data = base64.b64decode(audio_info["data"])
                        audio_chunks.append(chunk_data)
                    
                    # Get final audio URL
                    if audio_info.get("url"):
                        audio_url = audio_info["url"]
                    
                    request_id = data.get("request_id", request_id)
                    
                except json.JSONDecodeError:
                    continue
        
        # Concatenate all audio chunks
        audio_data = b"".join(audio_chunks)
        
        # If no streaming chunks but we have URL, download from URL
        if not audio_data and audio_url:
            audio_response = self.client.get(audio_url)
            if audio_response.status_code == 200:
                audio_data = audio_response.content
        
        if not audio_data:
            raise RuntimeError("No audio data received from streaming response")
        
        # Save to file if specified
        if output_file:
            output_file = Path(output_file)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_bytes(audio_data)

        return AudioResponse(
            audio_data=audio_data,
            content_type="audio/pcm",  # Streaming returns PCM format
            model=self.model_name,
            voice=voice,
            provider=self.PROVIDER,
            metadata={
                "text": payload.get("text"),
                "language_type": payload.get("language_type"),
                "audio_url": audio_url,
                "request_id": request_id,
                "streaming": True,
            }
        )

    async def agenerate_speech(
        self,
        text: str,
        voice: str = "Cherry",
        output_file: Optional[Union[str, Path]] = None,
        language_type: Optional[str] = None,
        stream: bool = False,
        **kwargs
    ) -> AudioResponse:
        """Generate speech from text using Dashscope Qwen-TTS API asynchronously.

        Args:
            text: Text to convert to speech
            voice: Voice to use (default: "Cherry")
            output_file: Optional path to save the audio file
            language_type: Language type override. If not provided, uses instance default.
            stream: Whether to use streaming mode (default: False)
            **kwargs: Additional parameters to pass to the API

        Returns:
            AudioResponse containing the audio data and metadata

        Raises:
            RuntimeError: If speech generation fails
            ValueError: If input parameters are invalid
        """
        self.validate_parameters(text, voice, self.model_name)
        
        try:
            # Prepare request payload
            payload = {
                "model": self.model_name,
                "text": text,
                "voice": voice,
                "stream": stream,
                "language_type": language_type or self.language_type,
                **kwargs
            }

            if stream:
                return await self._agenerate_speech_streaming(payload, voice, output_file)
            else:
                return await self._agenerate_speech_non_streaming(payload, voice, output_file)

        except Exception as e:
            if isinstance(e, (RuntimeError, ValueError)):
                raise
            raise RuntimeError(f"Failed to generate speech: {str(e)}") from e

    async def _agenerate_speech_non_streaming(
        self,
        payload: Dict[str, Any],
        voice: str,
        output_file: Optional[Union[str, Path]] = None
    ) -> AudioResponse:
        """Generate speech in non-streaming mode asynchronously.
        
        Args:
            payload: Request payload
            voice: Voice name used
            output_file: Optional path to save the audio file
            
        Returns:
            AudioResponse with audio data
        """
        # Build request body with model at top level
        model = payload.pop("model")
        stream = payload.pop("stream", False)
        
        request_body = {
            "model": model,
            "input": payload,
        }
        
        # Call the multimodal conversation endpoint for TTS
        response = await self.async_client.post(
            f"{self.base_url}/services/aigc/multimodal-generation/generation",
            headers=self._get_headers(),
            json=request_body,
        )
        self._handle_error(response)
        
        response_data = response.json()
        
        # Extract audio URL from response
        output = response_data.get("output", {})
        audio_info = output.get("audio", {})
        audio_url = audio_info.get("url")
        
        if not audio_url:
            raise RuntimeError("No audio URL in response")
        
        # Download audio from URL
        audio_response = await self.async_client.get(audio_url)
        if audio_response.status_code != 200:
            raise RuntimeError(f"Failed to download audio: HTTP {audio_response.status_code}")
        
        audio_data = audio_response.content
        
        # Save to file if specified
        if output_file:
            output_file = Path(output_file)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_bytes(audio_data)

        # Extract usage info
        usage = response_data.get("usage", {})
        
        return AudioResponse(
            audio_data=audio_data,
            content_type="audio/wav",
            model=self.model_name,
            voice=voice,
            provider=self.PROVIDER,
            metadata={
                "text": payload.get("text"),
                "language_type": payload.get("language_type"),
                "audio_url": audio_url,
                "request_id": response_data.get("request_id"),
                "input_characters": usage.get("input_characters"),
                "output_tokens": usage.get("output_tokens"),
            }
        )

    async def _agenerate_speech_streaming(
        self,
        payload: Dict[str, Any],
        voice: str,
        output_file: Optional[Union[str, Path]] = None
    ) -> AudioResponse:
        """Generate speech in streaming mode asynchronously.
        
        Args:
            payload: Request payload
            voice: Voice name used
            output_file: Optional path to save the audio file
            
        Returns:
            AudioResponse with concatenated audio data
        """
        # Build request body with model at top level
        model = payload.pop("model")
        stream = payload.pop("stream", True)
        
        request_body = {
            "model": model,
            "input": payload,
            "parameters": {
                "incremental_output": True
            }
        }
        
        # For streaming, we need to handle Server-Sent Events
        headers = self._get_headers()
        headers["Accept"] = "text/event-stream"
        headers["X-DashScope-SSE"] = "enable"
        
        response = await self.async_client.post(
            f"{self.base_url}/services/aigc/multimodal-generation/generation",
            headers=headers,
            json=request_body,
        )
        self._handle_error(response)
        
        # Collect all audio chunks
        audio_chunks = []
        audio_url = None
        request_id = None
        
        async for line in response.aiter_lines():
            if not line:
                continue
            
            if line.startswith("data:"):
                try:
                    import json
                    data = json.loads(line[5:].strip())
                    output = data.get("output", {})
                    audio_info = output.get("audio", {})
                    
                    # Get base64 audio chunk
                    if audio_info.get("data"):
                        chunk_data = base64.b64decode(audio_info["data"])
                        audio_chunks.append(chunk_data)
                    
                    # Get final audio URL
                    if audio_info.get("url"):
                        audio_url = audio_info["url"]
                    
                    request_id = data.get("request_id", request_id)
                    
                except json.JSONDecodeError:
                    continue
        
        # Concatenate all audio chunks
        audio_data = b"".join(audio_chunks)
        
        # If no streaming chunks but we have URL, download from URL
        if not audio_data and audio_url:
            audio_response = await self.async_client.get(audio_url)
            if audio_response.status_code == 200:
                audio_data = audio_response.content
        
        if not audio_data:
            raise RuntimeError("No audio data received from streaming response")
        
        # Save to file if specified
        if output_file:
            output_file = Path(output_file)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_bytes(audio_data)

        return AudioResponse(
            audio_data=audio_data,
            content_type="audio/pcm",  # Streaming returns PCM format
            model=self.model_name,
            voice=voice,
            provider=self.PROVIDER,
            metadata={
                "text": payload.get("text"),
                "language_type": payload.get("language_type"),
                "audio_url": audio_url,
                "request_id": request_id,
                "streaming": True,
            }
        )

    def generate_speech_stream(
        self,
        text: str,
        voice: str = "Cherry",
        language_type: Optional[str] = None,
        **kwargs
    ) -> Iterator[bytes]:
        """Generate speech with streaming output, yielding audio chunks.

        This is useful for real-time audio playback scenarios.

        Args:
            text: Text to convert to speech
            voice: Voice to use (default: "Cherry")
            language_type: Language type override
            **kwargs: Additional parameters

        Yields:
            bytes: PCM audio chunks (16-bit, 24kHz, mono)
            
        Example:
            >>> import pyaudio
            >>> p = pyaudio.PyAudio()
            >>> stream = p.open(format=pyaudio.paInt16, channels=1, rate=24000, output=True)
            >>> for chunk in tts.generate_speech_stream("你好", voice="Cherry"):
            ...     stream.write(chunk)
        """
        self.validate_parameters(text, voice, self.model_name)
        
        # Build request body with model at top level
        request_body = {
            "model": self.model_name,
            "input": {
                "text": text,
                "voice": voice,
                "language_type": language_type or self.language_type,
                **kwargs
            },
            "parameters": {
                "incremental_output": True
            }
        }
        
        headers = self._get_headers()
        headers["Accept"] = "text/event-stream"
        headers["X-DashScope-SSE"] = "enable"
        
        with self.client.stream(
            "POST",
            f"{self.base_url}/services/aigc/multimodal-generation/generation",
            headers=headers,
            json=request_body,
        ) as response:
            if response.status_code >= 400:
                raise RuntimeError(f"Dashscope API error: HTTP {response.status_code}")
            
            for line in response.iter_lines():
                if not line:
                    continue
                
                line_str = line.decode("utf-8") if isinstance(line, bytes) else line
                if line_str.startswith("data:"):
                    try:
                        import json
                        data = json.loads(line_str[5:].strip())
                        output = data.get("output", {})
                        audio_info = output.get("audio", {})
                        
                        if audio_info.get("data"):
                            yield base64.b64decode(audio_info["data"])
                            
                    except json.JSONDecodeError:
                        continue
